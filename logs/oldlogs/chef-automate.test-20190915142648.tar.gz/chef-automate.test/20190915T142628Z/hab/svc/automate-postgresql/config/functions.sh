write_local_conf() {
  echo 'Writing postgresql.local.conf file based on memory settings'
  cat > /hab/svc/automate-postgresql/config/postgresql.local.conf<<LOCAL
# Auto-generated memory defaults created at service start by Habitat
effective_cache_size=$(awk '/MemTotal/ {printf( "%.0f\n", ($2 / 1024 / 4) *3 )}' /proc/meminfo)MB
shared_buffers=$(awk '/MemTotal/ {printf( "%.0f\n", $2 / 1024 / 4 )}' /proc/meminfo)MB
work_mem=$(awk '/MemTotal/ {printf( "%.0f\n", (($2 / 1024 / 4) *3) / (100 *3) )}' /proc/meminfo)MB
maintenance_work_mem=$(awk '/MemTotal/ {printf( "%.0f\n", $2 / 1024 / 16 )}' /proc/meminfo)MB
temp_buffers=$(awk '/MemTotal/ {printf( "%.0f\n", (($2 / 1024 / 4) *3) / (100*3) )}' /proc/meminfo)MB
LOCAL
}

ensure_dir_ownership() {
  paths="/hab/svc/automate-postgresql/var /hab/svc/automate-postgresql/data"
  if [[ $EUID -eq 0 ]]; then
    # if EUID is root, so we should chown to pkg_svc_user:pkg_svc_group
    ownership_command="chown -RL hab:hab $paths"
  else
    # not root, so at best we can only chgrp to the effective user's primary group
    ownership_command="chgrp -RL $(id -g) $paths"
  fi
  echo "Ensuring proper ownership: $ownership_command"
  $ownership_command
  chmod 0700 /hab/svc/automate-postgresql/data/pgdata
}

ensure_key_ownership() {
  keys=(server.crt server.key root.crt)
  for k in "${keys[@]}"
  do
    chmod 0600 "/hab/svc/automate-postgresql/config/$k"
  done
}
